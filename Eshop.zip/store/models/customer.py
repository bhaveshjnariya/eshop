from django.db import models

class Customer(models.Model):
    first = models.CharField(max_length=45)
    last = models.CharField(max_length=45)
    email = models.EmailField()
    phone = models.CharField(max_length=15, default='', null=True, blank=True)
    password = models.CharField(max_length=500)

    def register(self):
        self.save()

    @staticmethod
    def get_customer_by_email(email):
        try:
            return Customer.objects.filter(email = email)
        except:
            return False


    def customerExist(self):
        if Customer.objects.filter(email = self.email):
            return True
        else:
            return False