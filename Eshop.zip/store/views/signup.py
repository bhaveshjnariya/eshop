from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from store.models.customer import Customer
from django.views import View


class Signup(View):

    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        first = postData.get('first')
        last = postData.get('last')
        email = postData.get('email')
        phone = postData.get('phone')
        password = postData.get('password')
        # Validation
        values = {
            'first': first,
            'last': last,
            'email': email,
            'phone': phone,
        }
        customer = Customer(first=first, last=last, email=email, phone=phone, password=password)
        error_message = self.validateCustomer(customer)

        # save customer
        if not error_message:
            customer.password = make_password(customer.password)
            customer.register();
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'values': values
            }
            return render(request, 'signup.html', data)

    def validateCustomer(customer):
        error_message = None
        if not customer.first:
            error_message = 'First Name is required!'
        elif not customer.last:
            error_message = 'Last Name is required!'
        elif not customer.email:
            error_message = 'Email is required!'
        elif len(customer.password) < 6:
            error_message = 'Password is too short!'
        elif customer.customerExist():
            error_message = 'Email address already exist!'

        return error_message