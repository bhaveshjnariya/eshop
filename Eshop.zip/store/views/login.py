from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password, make_password
from django.contrib.auth import logout
from store.models.customer import Customer
from django.views import View
from django.http import HttpResponseRedirect

class Login(View):

    returnUrl = None
    def get(self, request):
        Login.returnUrl = request.GET.get('return')
        return render(request, 'login.html')

    def post(self, request):
        postData = request.POST
        email = postData.get('email')
        password = postData.get('password')
        # Validation
        customer = Customer.get_customer_by_email(email)
        error_message = None

        if customer:
            flag = check_password(password, customer[0].password)
            if flag:
                request.session['customer_id'] = customer[0].id
                request.session['name'] = customer[0].first
                request.session['email'] = customer[0].email
                if Login.returnUrl:
                    return HttpResponseRedirect(Login.returnUrl)
                else:
                    Login.returnUrl = None
                    return redirect('homepage')
            else:
                error_message = 'Email or Password invalid !!'
        else:
            error_message = 'Email or Password invalid !!'
        # start session
        if not error_message:
            customer.password = make_password(customer.password)
            customer.register();
            return redirect('homepage')
        else:
            return render(request, 'login.html', {'error': error_message})

    def logout(request):
        request.session.clear()
        return redirect('login')
