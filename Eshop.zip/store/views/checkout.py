from django.shortcuts import render, redirect
from django.views import View
from store.models.product import Product
from store.models.orders import Orders
from store.models.customer import Customer

class Checkout(View):

    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer_id')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))

        for product in products:
            order = Orders(
                        product = Product(id = product.id),
                        customer = Customer(id = customer),
                        price = product.price,
                        quantity = cart.get(str(product.id)),
                        address = address,
                        phone = phone)
            order.place_order()

        request.session['cart'] = {}
        return redirect('orders')

